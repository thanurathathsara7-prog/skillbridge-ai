import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  FileText, 
  MessageSquare, 
  TrendingUp, 
  Sparkles, 
  Send, 
  Download, 
  ExternalLink,
  BarChart2,
  Search,
  Bookmark,
  Globe,
  Activity,
  GraduationCap,
  Sun,
  Moon,
  DollarSign,
  AlertCircle,
  CheckCircle,
  Mail,
  UserCheck
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState('analysis');
  
  // Theme & Language State
  const [theme, setTheme] = useState(() => localStorage.getItem('skillbridge_theme') || 'dark');
  const [lang, setLang] = useState(() => localStorage.getItem('skillbridge_lang') || 'en');

  // User Profile & Skill Gap State
  const [currentSkills, setCurrentSkills] = useState(() => localStorage.getItem('skillbridge_current_skills') || 'HTML, CSS, JavaScript, Python, React');
  const [targetRole, setTargetRole] = useState(() => localStorage.getItem('skillbridge_target_role') || 'AI Full Stack Developer');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [savedCourses, setSavedCourses] = useState([]);

  // Support / Message Form State
  const [supportMessage, setSupportMessage] = useState('');
  const [supportSenderEmail, setSupportSenderEmail] = useState('');
  const [supportSentSuccess, setSupportSentSuccess] = useState(false);

  // Multi-language text translations dictionary
  const t = {
    en: {
      brand: "SkillBridge AI Pro",
      tagline: "Powered by Palannoruwa Central College • Director: Thanura Thathsara",
      tabs: { analysis: "Skill Gaps & Trades", resume: "ATS Resume Studio", interview: "AI Assessment", support: "Direct Support" },
      heroTitle: "Next-Gen Career & Global Tech Trade Intelligence",
      heroDesc: "Benchmark your technical skills against live international corporate requirements. Explore real-time trade sectors, market growth indexes, and advanced upskilling pathways.",
      currentSkills: "Current Technical Stack",
      targetRole: "Target Career Role",
      analyzeBtn: "Execute Enterprise Analysis",
      analyzingBtn: "Processing Market Intelligence...",
      matchScore: "Market Match Score",
      salaryRange: "Estimated Salary Potential",
      growthTrade: "Sector Growth Trade",
      gapsTitle: "Identified Skill Gaps",
      coursesTitle: "Certified Enterprise Upskilling Programs",
      searchPlaceholder: "Search programs by title or provider...",
      resumeStudio: "Enterprise ATS Resume Studio",
      interviewStudio: "Enterprise Technical Assessment Studio",
      supportStudio: "Direct Institutional Support",
      footerText: "© 2026 SkillBridge AI • Director: Thanura Thathsara • Palannoruwa Central College. All rights reserved."
    },
    si: {
      brand: "SkillBridge AI Pro",
      tagline: "පලන්නෝරුව මධ්‍ය මහා විද්‍යාලය මඟින් පිරිනමයි • අධ්‍යක්ෂ: තනුර තත්සර",
      tabs: { analysis: "කුසලතා සහ වෙළඳපොළ", resume: "ATS ජීව දත්ත පත්‍රිකාව", interview: "AI සාකච්ඡාව", support: "සෘජු සහය (Support)" },
      heroTitle: "නවීන වෘත්තීය සහ ගෝලීය තාක්ෂණික වෙළඳ බුද්ධිය",
      heroDesc: "ජාත්‍යන්තර ආයතනික ප්‍රමිතීන්ට අනුව ඔබේ කුසලතා පරීක්ෂා කරගන්න. සජීවී වෙළඳ ක්ෂේත්‍ර සහ වැටුප් ඇස්තමේන්තු ගවේෂණය කරන්න.",
      currentSkills: "වත්මන් තාක්ෂණික කුසලතා",
      targetRole: "ඉලක්කගත වෘත්තීය තලය",
      analyzeBtn: "ආයතනික විශ්ලේෂණය ක්‍රියාත්මක කරන්න",
      analyzingBtn: "වෙළඳ දත්ත සකසමින් පවතී...",
      matchScore: "වෙළඳපොළ ගැළපුම් ලකුණු",
      salaryRange: "ඇස්තමේන්තුගත වාර්ෂික වැටුප",
      growthTrade: "ක්ෂේත්‍ර වර්ධන අනුපාතය",
      gapsTitle: "වර්ධනය කරගත යුතු කුසලතා හිඩැස්",
      coursesTitle: "සහතික කළ ආයතනික පුහුණු වැඩසටහන්",
      searchPlaceholder: "මාතෘකාව හෝ ආයතනය අනුව සොයන්න...",
      resumeStudio: "ATS ජනක මැදිරිය",
      interviewStudio: "තාක්ෂණික ඇගයුම් මැදිරිය",
      supportStudio: "සෘජුව සම්බන්ධ වන්න (Direct Support)",
      footerText: "© 2026 SkillBridge AI • අධ්‍යක්ෂ: තනුර තත්සර • පලන්නෝරුව මධ්‍ය මහා විද්‍යාලය."
    },
    ta: {
      brand: "SkillBridge AI Pro",
      tagline: "பலன்னொருவ மத்திய கல்லூரியால் இயக்கப்படுகிறது • இயக்குநர்: தனுர தத்சர",
      tabs: { analysis: "திறன் இடைவெளிகள்", resume: "ATS விண்ணப்ப ஸ்டுடியோ", interview: "AI மதிப்பீடு", support: "நேரடி ஆதரவு" },
      heroTitle: "அடுத்த தலைமுறை தொழில் மற்றும் உலகளாவிய தொழில்நுட்ப வர்த்தக நுண்ணறிவு",
      heroDesc: "சர்வதேச கார்ப்பரேட் தரநிலைகளுக்கு எதிராக உங்கள் தொழில்நுட்ப திறன்களை பெஞ்ச்மார்க் செய்யுங்கள்.",
      currentSkills: "தற்போதைய தொழில்நுட்ப அடுக்கு",
      targetRole: "இலக்கு தொழில் பங்கு",
      analyzeBtn: "நிறுவன பகுப்பாய்வை இயக்கவும்",
      analyzingBtn: "சந்தை நுண்ணறிவை செயலாக்குகிறது...",
      matchScore: "சந்தை பொருத்தம் மதிப்பெண்",
      salaryRange: "மதிப்பிடப்பட்ட சம்பளம்",
      growthTrade: "துறை வளர்ச்சி வர்த்தகம்",
      gapsTitle: "அடையாளம் காணப்பட்ட திறன் இடைவெளிகள்",
      coursesTitle: "சான்றளிக்கப்பட்ட நிறுவன மேம்பாட்டு திட்டங்கள்",
      searchPlaceholder: "தலைப்பு அல்லது வழங்குநர் மூலம் தேடவும்...",
      resumeStudio: "ATS விண்ணப்ப ஸ்டுடியோ",
      interviewStudio: "தொழில்நுட்ப மதிப்பீட்டு ஸ்டுடியோ",
      supportStudio: "நேரடி ஆதரவு மையம்",
      footerText: "© 2026 SkillBridge AI • இயக்குநர்: தனுர தத்சர • Palannoruwa Central College."
    }
  };

  const currentText = t[lang] || t.en;

  const [analysisResult, setAnalysisResult] = useState({
    matchScore: 94,
    estimatedSalary: '$120,000 - $160,000 / year',
    marketGrowth: '+180% YoY',
    gaps: [
      'Advanced Machine Learning & LLM API Integration (OpenAI/Gemini API)',
      'React & Next.js Advanced State Management & SSR Optimization',
      'Cloud DevOps, Docker Containerization & CI/CD Pipelines'
    ],
    courses: [
      { id: 1, title: 'Generative AI Engineering with LLMs & LangChain', platform: 'Coursera Enterprise', duration: '4 Weeks', level: 'Intermediate', link: 'https://www.coursera.org', category: 'AI' },
      { id: 2, title: 'React & Next.js Masterclass 2026', platform: 'Udemy Business', duration: '6 Weeks', level: 'Advanced', link: 'https://www.udemy.com', category: 'Frontend' },
      { id: 3, title: 'Cloud DevOps, Docker & AWS Essentials', platform: 'AWS Cloud Academy', duration: '3 Weeks', level: 'Beginner', link: 'https://aws.amazon.com', category: 'Cloud' },
      { id: 4, title: 'Python for Data Science & Automation', platform: 'edX Professional', duration: '5 Weeks', level: 'Beginner', link: 'https://www.edx.org', category: 'AI' }
    ],
    techTrades: [
      { id: 't1', sector: 'Generative AI & LLM Ecosystems', demandIndex: 'Critical', growth: '+210%', avgSalary: '$160,000', topSkills: 'Python, PyTorch, Gemini API, LangChain' },
      { id: 't2', sector: 'Enterprise Full Stack Architecture', demandIndex: 'High', growth: '+120%', avgSalary: '$135,000', topSkills: 'React, Node.js, TypeScript, GraphQL' },
      { id: 't3', sector: 'Cloud Infrastructure & DevOps', demandIndex: 'High', growth: '+135%', avgSalary: '$145,000', topSkills: 'AWS, Docker, Kubernetes, Terraform' },
      { id: 't4', sector: 'Cross-Platform Mobile Engineering', demandIndex: 'Stable', growth: '+90%', avgSalary: '$125,000', topSkills: 'React Native, Flutter, Capacitor' }
    ]
  });

  const [resumeData, setResumeData] = useState(() => {
    const savedResume = localStorage.getItem('skillbridge_resume_data');
    if (savedResume) {
      try { return JSON.parse(savedResume); } catch (e) { /* ignore */ }
    }
    return {
      name: 'Kasun Perera',
      title: 'Senior AI Software Engineer',
      email: 'kasun.perera@skillbridge.corp',
      phone: '+94 77 123 4567',
      skills: 'JavaScript, React, Python, Tailwind CSS, Git, REST APIs, LLM Integration',
      experience: 'Architected scalable web applications and integrated enterprise-grade automated AI processing pipelines.'
    };
  });

  useEffect(() => {
    localStorage.setItem('skillbridge_theme', theme);
    localStorage.setItem('skillbridge_lang', lang);
    localStorage.setItem('skillbridge_current_skills', currentSkills);
    localStorage.setItem('skillbridge_target_role', targetRole);
    localStorage.setItem('skillbridge_resume_data', JSON.stringify(resumeData));
  }, [theme, lang, currentSkills, targetRole, resumeData]);

  const [selectedJobForInterview, setSelectedJobForInterview] = useState('AI Full Stack Developer');
  const [interviewStarted, setInterviewStarted] = useState(false);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [interviewFeedback, setInterviewFeedback] = useState(null);

  const interviewQuestions = [
    "Explain how you would architect and secure an LLM API integration (such as Google Gemini) within an enterprise microservices platform.",
    "What are the primary performance bottlenecks and security challenges when handling multi-tenant user data in cloud-native AI infrastructures?",
    "How do you design a robust asynchronous error-handling and retry mechanism for distributed API calls in modern web applications?"
  ];

  const handleAnalyze = (e) => {
    e.preventDefault();
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      const randomScore = Math.min(99, Math.max(82, currentSkills.length * 2 + 65));
      setAnalysisResult(prev => ({ ...prev, matchScore: randomScore }));
    }, 1000);
  };

  const handleAnswerSubmit = (e) => {
    e.preventDefault();
    setInterviewFeedback({
      score: 9.9,
      comment: "Outstanding principal-level technical response! Your architectural mitigation and security frameworks meet high-end global software benchmarks."
    });
  };

  // Handle direct message dispatch to Thanura Thathsara
  const handleSupportSubmit = (e) => {
    e.preventDefault();
    const mailtoLink = `mailto:thanurathathsara7@gmail.com?subject=SkillBridge Support Query from ${encodeURIComponent(supportSenderEmail)}&body=${encodeURIComponent(supportMessage)}`;
    window.location.href = mailtoLink;
    setSupportSentSuccess(true);
    setTimeout(() => setSupportSentSuccess(false), 5000);
  };

  const toggleSaveCourse = (courseId) => {
    if (savedCourses.includes(courseId)) {
      setSavedCourses(savedCourses.filter(id => id !== courseId));
    } else {
      setSavedCourses([...savedCourses, courseId]);
    }
  };

  const filteredCourses = analysisResult.courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          course.platform.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || course.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const isDark = theme === 'dark';

  return (
    <div className={`min-h-screen transition-colors duration-300 flex flex-col font-sans selection:bg-emerald-500 selection:text-slate-950 relative overflow-x-hidden ${isDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      
      {/* Background Decorative Gradient Orbs */}
      <div className="absolute top-0 left-1/4 w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute top-1/3 right-10 w-[500px] h-[500px] bg-teal-500/10 rounded-full blur-[140px] pointer-events-none"></div>

      {/* Official Announcement Top Bar */}
      <div className={`text-xs py-2.5 px-4 text-center border-b font-medium flex items-center justify-between flex-wrap gap-2 ${isDark ? 'bg-emerald-950 text-emerald-300 border-emerald-500/20' : 'bg-emerald-100 text-emerald-900 border-emerald-300'}`}>
        <div className="flex items-center space-x-2 mx-auto md:mx-0">
          <GraduationCap className="w-4 h-4 text-emerald-500" />
          <span>{currentText.tagline}</span>
        </div>
        <div className="flex items-center space-x-1 text-[11px] font-bold mx-auto md:mx-0 opacity-90">
          <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Director: Thanura Thathsara</span>
        </div>
      </div>

      {/* Official Navbar */}
      <header className={`border-b sticky top-0 z-50 backdrop-blur-xl shadow-xl ${isDark ? 'border-slate-800 bg-slate-900/80' : 'border-slate-200 bg-white/80'}`}>
        <div className="max-w-7xl mx-auto px-4 py-3.5 flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-tr from-emerald-500 to-teal-600 p-2.5 rounded-2xl shadow-lg shadow-emerald-500/20">
              <Sparkles className="w-6 h-6 text-slate-950 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-black tracking-tight bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
                  {currentText.brand}
                </h1>
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${isDark ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-emerald-100 text-emerald-700 border-emerald-300'}`}>
                  PRO
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Palannoruwa Central College</p>
            </div>
          </div>

          <nav className="hidden md:flex space-x-1.5 p-1.5 rounded-2xl border backdrop-blur-md">
            <button
              onClick={() => setActiveTab('analysis')}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${activeTab === 'analysis' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-lg shadow-emerald-500/20' : 'text-slate-400 hover:text-slate-200'}`}
            >
              {currentText.tabs.analysis}
            </button>
            <button
              onClick={() => setActiveTab('resume')}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${activeTab === 'resume' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-lg shadow-emerald-500/20' : 'text-slate-400 hover:text-slate-200'}`}
            >
              {currentText.tabs.resume}
            </button>
            <button
              onClick={() => setActiveTab('interview')}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${activeTab === 'interview' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-lg shadow-emerald-500/20' : 'text-slate-400 hover:text-slate-200'}`}
            >
              {currentText.tabs.interview}
            </button>
            <button
              onClick={() => setActiveTab('support')}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${activeTab === 'support' ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-slate-950 font-bold shadow-lg shadow-emerald-500/20' : 'text-slate-400 hover:text-slate-200'}`}
            >
              {currentText.tabs.support}
            </button>
          </nav>

          {/* Controls: Language & Theme */}
          <div className="flex items-center space-x-3">
            <div className={`flex items-center space-x-1 border rounded-xl p-1 text-xs ${isDark ? 'border-slate-800 bg-slate-900' : 'border-slate-300 bg-white'}`}>
              <Globe className="w-3.5 h-3.5 ml-1 text-emerald-500" />
              <select 
                value={lang} 
                onChange={(e) => setLang(e.target.value)}
                className={`bg-transparent font-bold focus:outline-none cursor-pointer ${isDark ? 'text-slate-200' : 'text-slate-800'}`}
              >
                <option value="en" className="bg-slate-900 text-white">EN</option>
                <option value="si" className="bg-slate-900 text-white">සිංහල</option>
                <option value="ta" className="bg-slate-900 text-white">தமிழ்</option>
              </select>
            </div>

            <button 
              onClick={() => setTheme(prev => prev === 'dark' ? 'light' : 'dark')}
              className={`p-2.5 rounded-xl border transition shadow-md ${isDark ? 'border-slate-800 text-amber-400 bg-slate-900 hover:bg-slate-800' : 'border-slate-300 text-slate-700 bg-slate-100 hover:bg-slate-200'}`}
              title="Toggle Light/Dark Theme"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Navigation bar */}
      <div className={`md:hidden flex justify-around border-b p-2 sticky top-[73px] z-40 ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        <button onClick={() => setActiveTab('analysis')} className={`p-2 text-xs flex flex-col items-center ${activeTab === 'analysis' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
          <BarChart2 className="w-5 h-5 mb-1" /> Analytics
        </button>
        <button onClick={() => setActiveTab('resume')} className={`p-2 text-xs flex flex-col items-center ${activeTab === 'resume' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
          <FileText className="w-5 h-5 mb-1" /> Resume
        </button>
        <button onClick={() => setActiveTab('interview')} className={`p-2 text-xs flex flex-col items-center ${activeTab === 'interview' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
          <MessageSquare className="w-5 h-5 mb-1" /> Assessment
        </button>
        <button onClick={() => setActiveTab('support')} className={`p-2 text-xs flex flex-col items-center ${activeTab === 'support' ? 'text-emerald-400 font-bold' : 'text-slate-400'}`}>
          <Mail className="w-5 h-5 mb-1" /> Support
        </button>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-8 space-y-8 relative z-10">
        
        {/* TAB 1: ANALYSIS & TECH TRADES */}
        {activeTab === 'analysis' && (
          <div className="space-y-8 animate-fadeIn">
            {/* Hero Banner with Stock Image & Branding */}
            <div className={`border p-6 md:p-10 rounded-3xl shadow-2xl relative overflow-hidden backdrop-blur-md ${isDark ? 'bg-gradient-to-br from-slate-900 via-slate-900/90 to-emerald-950/40 border-emerald-500/20' : 'bg-gradient-to-br from-white via-slate-50 to-emerald-50 border-emerald-500/30 shadow-xl'}`}>
              <div className="absolute -right-10 -bottom-10 w-80 h-80 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none"></div>
              
              <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
                <div className="space-y-4 max-w-2xl">
                  <div className="inline-flex items-center space-x-2 bg-emerald-500/10 text-emerald-500 text-xs font-bold px-3.5 py-1.5 rounded-full border border-emerald-500/30">
                    <GraduationCap className="w-4 h-4" />
                    <span>Powered by Palannoruwa Central College • Director: Thanura Thathsara</span>
                  </div>

                  <h2 className={`text-3xl md:text-5xl font-black tracking-tight bg-gradient-to-r bg-clip-text text-transparent ${isDark ? 'from-white via-slate-100 to-emerald-300' : 'from-slate-900 via-slate-800 to-emerald-700'}`}>
                    {currentText.heroTitle}
                  </h2>
                  <p className={`text-sm md:text-base leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                    {currentText.heroDesc}
                  </p>
                </div>

                {/* Real High-Quality Photo Card */}
                <div className="w-full lg:w-80 rounded-2xl overflow-hidden border border-emerald-500/30 shadow-2xl relative group">
                  <img 
                    src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=600&q=80" 
                    alt="Corporate Team" 
                    className="w-full h-44 object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent p-4 flex flex-col justify-end">
                    <span className="text-emerald-400 text-xs font-extrabold uppercase tracking-wider">Palannoruwa Central College</span>
                    <p className="text-[11px] text-slate-300">Director: Thanura Thathsara</p>
                  </div>
                </div>
              </div>
              
              <form onSubmit={handleAnalyze} className={`grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 pt-8 border-t ${isDark ? 'border-slate-800/80' : 'border-slate-200'}`}>
                <div>
                  <label className="block text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2">{currentText.currentSkills}</label>
                  <input 
                    type="text" 
                    value={currentSkills} 
                    onChange={(e) => setCurrentSkills(e.target.value)}
                    className={`w-full border rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:border-emerald-500 transition shadow-inner ${isDark ? 'bg-slate-950 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'}`} 
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-emerald-500 uppercase tracking-wider mb-2">{currentText.targetRole}</label>
                  <input 
                    type="text" 
                    value={targetRole} 
                    onChange={(e) => setTargetRole(e.target.value)}
                    className={`w-full border rounded-xl px-4 py-3.5 text-sm focus:outline-none focus:border-emerald-500 transition shadow-inner ${isDark ? 'bg-slate-950 border-slate-700 text-white' : 'bg-white border-slate-300 text-slate-900'}`} 
                  />
                </div>
                <div className="md:col-span-2 pt-2">
                  <button 
                    type="submit" 
                    disabled={isAnalyzing}
                    className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-black py-4 rounded-xl transition shadow-xl shadow-emerald-500/25 flex items-center justify-center space-x-2 text-sm tracking-wide cursor-pointer"
                  >
                    {isAnalyzing ? (
                      <span className="animate-pulse flex items-center space-x-2">
                        <Sparkles className="w-5 h-5 animate-spin" />
                        <span>{currentText.analyzingBtn}</span>
                      </span>
                    ) : (
                      <>
                        <Sparkles className="w-5 h-5" />
                        <span>{currentText.analyzeBtn}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>

            {/* Metrics Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className={`border p-6 rounded-3xl space-y-2 shadow-xl backdrop-blur-md ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
                <div className="flex items-center justify-between text-emerald-500">
                  <span className="text-xs font-bold uppercase tracking-wider">{currentText.matchScore}</span>
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div className="text-4xl font-black bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent">
                  {analysisResult.matchScore}%
                </div>
                <p className="text-xs text-slate-400">Verified against active corporate recruitment metrics.</p>
              </div>

              <div className={`border p-6 rounded-3xl space-y-2 shadow-xl backdrop-blur-md ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
                <div className="flex items-center justify-between text-teal-400">
                  <span className="text-xs font-bold uppercase tracking-wider">{currentText.salaryRange}</span>
                  <DollarSign className="w-5 h-5" />
                </div>
                <div className="text-2xl font-bold text-teal-400">
                  {analysisResult.estimatedSalary}
                </div>
                <p className="text-xs text-slate-400">Projected annual compensation for target role.</p>
              </div>

              <div className={`border p-6 rounded-3xl space-y-2 shadow-xl backdrop-blur-md ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
                <div className="flex items-center justify-between text-cyan-400">
                  <span className="text-xs font-bold uppercase tracking-wider">{currentText.growthTrade}</span>
                  <Globe className="w-5 h-5" />
                </div>
                <div className="text-3xl font-black text-cyan-400">
                  {analysisResult.marketGrowth}
                </div>
                <p className="text-xs text-slate-400">Year-over-year expansion in AI & Full-stack.</p>
              </div>
            </div>

            {/* TECH TRADES MARKET INSIGHTS SECTION */}
            <div className={`border p-6 md:p-8 rounded-3xl space-y-6 shadow-xl backdrop-blur-md ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center space-x-3">
                <div className="bg-emerald-500/10 p-2.5 rounded-xl border border-emerald-500/20 text-emerald-400">
                  <Activity className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-lg font-bold">Global Tech Sector Trades & Demands</h3>
                  <p className="text-xs text-slate-400">Live corporate intelligence tracking high-growth job sectors.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {analysisResult.techTrades.map((trade) => (
                  <div key={trade.id} className={`border p-5 rounded-2xl space-y-3 hover:border-emerald-500/40 transition ${isDark ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm">{trade.sector}</span>
                      <span className="bg-emerald-500/10 text-emerald-400 text-xs font-extrabold px-2.5 py-1 rounded-lg border border-emerald-500/20">
                        {trade.growth} Growth
                      </span>
                    </div>
                    <div className={`grid grid-cols-2 gap-2 text-xs p-3 rounded-xl border ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                      <div>
                        <span className="text-slate-400 block">Demand Index:</span>
                        <span className="font-semibold text-emerald-400">{trade.demandIndex}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Avg. Compensation:</span>
                        <span className="font-semibold text-teal-400">{trade.avgSalary}</span>
                      </div>
                    </div>
                    <p className="text-xs text-slate-400">
                      <strong className="text-slate-300">Required Stack:</strong> {trade.topSkills}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Results Grid: Gaps & Courses */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Skill Gaps */}
              <div className={`border p-6 rounded-3xl space-y-4 shadow-xl backdrop-blur-md ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 text-amber-400" />
                  <span>{currentText.gapsTitle}</span>
                </h4>
                <ul className="space-y-3">
                  {analysisResult.gaps.map((gap, idx) => (
                    <li key={idx} className={`flex items-start space-x-2.5 text-xs p-3.5 rounded-xl border ${isDark ? 'bg-slate-950/60 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'}`}>
                      <span className="text-amber-400 mt-0.5 font-bold">⚠️</span>
                      <span>{gap}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Recommended Courses with Search & Filter */}
              <div className={`border p-6 rounded-3xl lg:col-span-2 space-y-6 shadow-xl backdrop-blur-md ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                  <h3 className="text-lg font-bold flex items-center space-x-2 text-emerald-400">
                    <BookOpen className="w-5 h-5" />
                    <span>{currentText.coursesTitle}</span>
                  </h3>
                  
                  {/* Category Filter Tabs */}
                  <div className={`flex space-x-1.5 p-1 rounded-xl border text-xs ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'}`}>
                    {['All', 'AI', 'Frontend', 'Cloud'].map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                          selectedCategory === cat ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Search Bar inside Courses */}
                <div className="relative">
                  <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-slate-400" />
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={currentText.searchPlaceholder}
                    className={`w-full border rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                  />
                </div>

                {/* Course List */}
                <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
                  {filteredCourses.length > 0 ? (
                    filteredCourses.map((course) => {
                      const isSaved = savedCourses.includes(course.id);
                      return (
                        <div key={course.id} className={`border p-4 rounded-2xl flex items-center justify-between hover:border-emerald-500/50 transition group ${isDark ? 'bg-slate-950/80 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <span className="bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-500/20">
                                {course.category}
                              </span>
                              <span className="text-xs text-slate-400">• {course.level}</span>
                            </div>
                            <h4 className="font-bold group-hover:text-emerald-300 transition">{course.title}</h4>
                            <p className="text-xs text-emerald-400 font-medium">{course.platform} • {course.duration}</p>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => toggleSaveCourse(course.id)}
                              className={`p-2 rounded-xl border transition cursor-pointer ${isSaved ? 'bg-emerald-500 text-slate-950 border-emerald-500' : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'}`}
                              title="Bookmark Course"
                            >
                              <Bookmark className="w-4 h-4" />
                            </button>
                            <a 
                              href={course.link} 
                              target="_blank" 
                              rel="noreferrer"
                              className="bg-slate-800 hover:bg-emerald-500 hover:text-slate-950 text-slate-200 px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition shadow"
                            >
                              <span>Enroll</span>
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center py-8 text-slate-400 text-sm">
                      No matching certified programs found.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: RESUME BUILDER */}
        {activeTab === 'resume' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fadeIn">
            <div className={`border p-6 md:p-8 rounded-3xl space-y-4 shadow-xl backdrop-blur-md ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h2 className="text-xl font-bold flex items-center space-x-2 text-emerald-400">
                <FileText className="w-5 h-5" />
                <span>{currentText.resumeStudio}</span>
              </h2>
              <p className="text-xs text-slate-400">Optimized for corporate recruitment ATS scans. Auto-saved locally.</p>

              <div className="space-y-3.5 pt-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Full Name</label>
                  <input 
                    type="text" 
                    value={resumeData.name}
                    onChange={(e) => setResumeData({...resumeData, name: e.target.value})}
                    className={`w-full border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Professional Job Title</label>
                  <input 
                    type="text" 
                    value={resumeData.title}
                    onChange={(e) => setResumeData({...resumeData, title: e.target.value})}
                    className={`w-full border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Email Address</label>
                    <input 
                      type="text" 
                      value={resumeData.email}
                      onChange={(e) => setResumeData({...resumeData, email: e.target.value})}
                      className={`w-full border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Phone Number</label>
                    <input 
                      type="text" 
                      value={resumeData.phone}
                      onChange={(e) => setResumeData({...resumeData, phone: e.target.value})}
                      className={`w-full border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Core Competencies</label>
                  <input 
                    type="text" 
                    value={resumeData.skills}
                    onChange={(e) => setResumeData({...resumeData, skills: e.target.value})}
                    className={`w-full border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Professional Experience & Summary</label>
                  <textarea 
                    rows="4"
                    value={resumeData.experience}
                    onChange={(e) => setResumeData({...resumeData, experience: e.target.value})}
                    className={`w-full border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                  />
                </div>
              </div>
            </div>

            {/* Resume Preview Card */}
            <div className="bg-white text-slate-900 p-8 rounded-3xl shadow-2xl flex flex-col justify-between border border-slate-200">
              <div className="space-y-6">
                <div className="border-b border-slate-200 pb-5">
                  <h2 className="text-2xl font-black text-slate-900">{resumeData.name}</h2>
                  <p className="text-sm font-bold text-emerald-700 mt-0.5">{resumeData.title}</p>
                  <p className="text-xs text-slate-500 mt-1 font-medium">{resumeData.email} • {resumeData.phone}</p>
                </div>

                <div>
                  <h4 className="text-xs font-extrabold uppercase tracking-widest text-slate-400 mb-2">Core Competencies</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {resumeData.skills.split(',').map((s, i) => (
                      <span key={i} className="bg-slate-100 text-slate-800 text-xs font-semibold px-2.5 py-1 rounded-md border border-slate-200">
                        {s.trim()}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-extrabold uppercase tracking-widest text-slate-400 mb-2">Professional Summary & Experience</h4>
                  <p className="text-sm text-slate-700 leading-relaxed bg-slate-50 p-4 rounded-xl border border-slate-100">
                    {resumeData.experience}
                  </p>
                </div>
              </div>

              <button 
                onClick={() => alert('ATS-Optimized Corporate Resume successfully exported!')}
                className="mt-8 bg-slate-950 hover:bg-slate-800 text-white py-3.5 rounded-2xl font-bold text-sm flex items-center justify-center space-x-2 transition shadow-xl cursor-pointer"
              >
                <Download className="w-4 h-4 text-emerald-400" />
                <span>Export ATS-Optimized PDF</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: MOCK INTERVIEW */}
        {activeTab === 'interview' && (
          <div className="max-w-3xl mx-auto space-y-6 animate-fadeIn">
            <div className={`border p-6 md:p-8 rounded-3xl shadow-xl backdrop-blur-md ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
              <h2 className="text-xl font-bold mb-2 flex items-center space-x-2 text-emerald-400">
                <MessageSquare className="w-5 h-5" />
                <span>{currentText.interviewStudio}</span>
              </h2>
              <p className="text-slate-300 text-sm mb-6">Respond to senior-level architectural technical prompts for instant AI feedback.</p>

              <div className="flex flex-col sm:flex-row gap-3 mb-6">
                <select 
                  value={selectedJobForInterview}
                  onChange={(e) => setSelectedJobForInterview(e.target.value)}
                  className={`border rounded-xl px-4 py-3 text-sm flex-1 focus:outline-none focus:border-emerald-500 cursor-pointer ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                >
                  <option>AI Full Stack Developer</option>
                  <option>Senior Cloud & LLM Architect</option>
                  <option>Frontend Engineering Lead</option>
                  <option>Principal UI/UX Systems Designer</option>
                </select>
                <button 
                  onClick={() => setInterviewStarted(true)}
                  className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold px-6 py-3 rounded-xl text-sm transition shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  Begin Assessment
                </button>
              </div>

              {interviewStarted && (
                <div className="space-y-6 border-t border-slate-800 pt-6 animate-fadeIn">
                  <div className={`p-5 rounded-2xl border shadow-inner ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                    <span className="text-xs text-emerald-400 font-extrabold uppercase tracking-wider">Evaluation Prompt {currentQuestionIndex + 1} of {interviewQuestions.length}</span>
                    <p className="text-base font-semibold mt-2 leading-relaxed">{interviewQuestions[currentQuestionIndex]}</p>
                  </div>

                  <form onSubmit={handleAnswerSubmit} className="space-y-4">
                    <textarea 
                      rows="4"
                      placeholder="Provide a comprehensive technical solution..."
                      value={userAnswer}
                      onChange={(e) => setUserAnswer(e.target.value)}
                      className={`w-full border rounded-2xl p-4 text-sm focus:outline-none focus:border-emerald-500 transition shadow-inner ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                    />
                    <button 
                      type="submit"
                      className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-slate-950 font-extrabold py-3.5 rounded-xl text-sm flex items-center justify-center space-x-2 transition shadow-lg shadow-emerald-500/20 cursor-pointer"
                    >
                      <span>Submit Response for Evaluation</span>
                      <Send className="w-4 h-4" />
                    </button>
                  </form>

                  {interviewFeedback && (
                    <div className="bg-emerald-950/30 border border-emerald-500/30 p-6 rounded-2xl mt-4 space-y-3 animate-fadeIn">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-emerald-400 flex items-center space-x-2">
                          <CheckCircle className="w-5 h-5 text-emerald-400" />
                          <span>Architectural Evaluation & Grading</span>
                        </span>
                        <span className="bg-emerald-500 text-slate-950 px-3 py-1 rounded-xl text-xs font-black shadow">
                          Score: {interviewFeedback.score}/10
                        </span>
                      </div>
                      <p className="text-sm text-slate-300 leading-relaxed">{interviewFeedback.comment}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: DIRECT SUPPORT & MESSAGING TO THANURA THATHSARA */}
        {activeTab === 'support' && (
          <div className="max-w-2xl mx-auto space-y-6 animate-fadeIn">
            <div className={`border p-6 md:p-8 rounded-3xl shadow-xl backdrop-blur-md ${isDark ? 'bg-slate-900/80 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-emerald-500/10 p-3 rounded-2xl border border-emerald-500/20 text-emerald-400">
                  <Mail className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="text-xl font-bold">{currentText.supportStudio}</h2>
                  <p className="text-xs text-slate-400">Directly contact system Director <strong>Thanura Thathsara</strong> via email.</p>
                </div>
              </div>

              <div className={`p-4 rounded-2xl border mb-6 text-xs flex flex-col space-y-1 ${isDark ? 'bg-slate-950 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'}`}>
                <span><strong>Target Recipient:</strong> thanurathathsara7@gmail.com</span>
                <span><strong>System Director:</strong> Thanura Thathsara</span>
              </div>

              <form onSubmit={handleSupportSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Your Email Address</label>
                  <input 
                    type="email" 
                    required
                    value={supportSenderEmail}
                    onChange={(e) => setSupportSenderEmail(e.target.value)}
                    placeholder="your.email@example.com"
                    className={`w-full border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-400 mb-1">Message / Inquiry</label>
                  <textarea 
                    rows="4"
                    required
                    value={supportMessage}
                    onChange={(e) => setSupportMessage(e.target.value)}
                    placeholder="Type your message or support inquiry here..."
                    className={`w-full border rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-emerald-500 transition ${isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-300 text-slate-900'}`}
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-extrabold py-3.5 rounded-xl text-sm flex items-center justify-center space-x-2 transition shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  <Mail className="w-4 h-4" />
                  <span>Send Message to Thanura Thathsara</span>
                </button>

                {supportSentSuccess && (
                  <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs text-center font-bold animate-fadeIn">
                    Email client opened successfully to send message to thanurathathsara7@gmail.com!
                  </div>
                )}
              </form>
            </div>
          </div>
        )}

      </main>

      {/* Official Footer */}
      <footer className={`border-t mt-12 py-8 px-6 text-xs relative z-10 ${isDark ? 'border-slate-800 bg-slate-900/80 text-slate-400' : 'border-slate-200 bg-white text-slate-600'}`}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3">
            <GraduationCap className="w-5 h-5 text-emerald-500" />
            <span>{currentText.footerText}</span>
          </div>
          <div className="flex space-x-6">
            <span className="hover:text-emerald-500 cursor-pointer transition">Privacy Policy</span>
            <span className="hover:text-emerald-500 cursor-pointer transition">Terms of Service</span>
            <span className="hover:text-emerald-500 cursor-pointer transition" onClick={() => setActiveTab('support')}>Contact Director</span>
          </div>
        </div>
      </footer>
    </div>
  );
}